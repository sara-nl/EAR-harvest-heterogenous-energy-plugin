double process_D(double *D);
