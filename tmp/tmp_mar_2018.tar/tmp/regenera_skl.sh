#!/bin/bash
autoreconf -i
./configure --with-papi=/home/xjcorbalan/my_papi --with-gsl=/home/xjcorbalan/my_gsl --with-slurm=/home/xjaneas/slurm --with-freeipmi=/home/xjcorbalan/my_freeipmi --prefix=/home/xjcorbalan/my_ear 

