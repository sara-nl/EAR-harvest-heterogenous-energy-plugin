export EAR_USER_DB_PATHNAME="my_db_pathname"
export EAR_APP_NAME="my_name"
export EAR_P_STATE=1
