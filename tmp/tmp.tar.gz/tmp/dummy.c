double process_D(double *D)
{
	return D[0];
}
